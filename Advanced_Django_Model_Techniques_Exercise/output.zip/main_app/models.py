from django.db import models
from django.core.exceptions import ValidationError
from django.core.validators import validate_email, URLValidator

def validate_name(value):
    for char in value:
        if not (char.isalpha() or char.isspace()):
            raise ValidationError("Name can only contain letters and spaces")

def validate_age(value):
    if value < 18:
        raise ValidationError("Age must be greater than or equal to 18")

def validate_phone_number(value):
    if not value.startswith("+359") or not value[4:].isdigit() or len(value) != 13:
        raise ValidationError("Phone number must start with '+359' followed by 9 digits")

def validate_website_url(value):
    url_validator = URLValidator()
    try:
        url_validator(value)
    except ValidationError:
        raise ValidationError("Enter a valid URL")

class Customer(models.Model):
    name = models.CharField(max_length=100, validators=[validate_name])
    age = models.PositiveIntegerField(validators=[validate_age])
    email = models.EmailField(validators=[validate_email])
    phone_number = models.CharField(max_length=13, validators=[validate_phone_number])
    website_url = models.URLField(validators=[validate_website_url])


import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

from main_app.models import Author, Book
from django.db.models import Prefetch

def show_all_authors_with_their_books():
    authors = Author.objects.all().prefetch_related(
        Prefetch('book_set', queryset=Book.objects.all(), to_attr='books')
    ).order_by("id")
    
    result = []

    for author in authors:
        if author.books:
            books_titles = ", ".join(book.title for book in author.books)
            result.append(f"{author.name} has written - {books_titles}!")

    return "\n".join(result)

def delete_all_authors_without_books():
    Author.objects.filter(book__isnull=True).delete()
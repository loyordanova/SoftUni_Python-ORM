from decimal import Decimal
import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# first_exercise -----------------------------------------------------------------------------------------
from main_app.models import Pet

def create_pet(name: str, species: str):
    Pet.objects.create(
        name=name,
        species=species
    )

    return f"{name} is a very cute {species}!"

# print(create_pet('Buddy', 'Dog'))
# print(create_pet('Whiskers', 'Cat'))
# print(create_pet('Rocky', 'Hamster'))

# second_exercise -----------------------------------------------------------------------------------------

from main_app.models import Artifact

def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool):
    artifact = Artifact.objects.create(
        name=name,
        origin=origin,
        age=age,
        description=description,
        is_magical=is_magical
    )

    return f'The artifact {artifact.name} is {artifact.age} years old!'


def delete_all_artifacts():
    Artifact.objects.all().delete()

# print(create_artifact('Ancient Sword', 'Lost Kingdom', 500, 'A legendary sword with a rich history', True))
# print(create_artifact('Crystal Amulet', 'Mystic Forest', 300, 'A magical amulet believed to bring good fortune', True))

# third_exercise -----------------------------------------------------------------------------------------

from main_app.models import Location

def show_all_locations():
    locations = Location.objects.all().order_by('-id')

    result = []

    for location in locations:
        result.append(f'{location.name} has a population of {location.population}!')
    
    return '\n'.join(result)



def new_capital():
    data = Location.objects.first()
    if data:
        data.is_capital = True
        data.save()

    # another way to solve that is faster

    # Location.objects.filter(pk=1).update(is_capital=True)


def get_capitals():
    capitals = Location.objects.filter(is_capital=True).values('name')
    return capitals

def delete_first_location():
    Location.objects.first().delete()

# forth_exercise -----------------------------------------------------------------------------------------
    
from main_app.models import Car

def apply_discount():
    cars = Car.objects.all()

    for car in cars:
        discount = sum(int(num) for num in str(car.year))
        discount_percentage = Decimal(discount) / Decimal(100)
        discount_amount = car.price * discount_percentage
        car.price_with_discount = car.price - discount_amount
        car.save()

def get_recent_cars():
    cars = Car.objects.all().filter(year__gt=2020).values('model', 'price_with_discount')
    return cars

def delete_last_car():
    Car.objects.last().delete()
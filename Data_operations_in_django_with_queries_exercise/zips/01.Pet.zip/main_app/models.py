from django.db import models


# first_exercise --------------------------------------------------------------------------------

class Pet(models.Model):
    name = models.CharField(
        max_length=40
    )

    species = models.CharField(
        max_length=40
    )

